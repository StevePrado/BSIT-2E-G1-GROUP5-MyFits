<?php
// Step 1: Detect the environment
$is_localhost = ($_SERVER['SERVER_NAME'] == 'localhost' || $_SERVER['SERVER_NAME'] == '127.0.0.1');

if ($is_localhost) {
    // --- XAMPP SETTINGS (Your Laptop) ---
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "myfits_db"; // Make sure this matches your local DB name!
} else {
    // --- INFINITYFREE SETTINGS (Online) ---
    $host = "sql104.infinityfree.com";
    $user = "if0_41441519";   
    $pass = "Accountmyfits1";    
    $dbname = "if0_41441519_myfits";
}

// Step 2: Establish the connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Step 3: Check for errors
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Success! Your code now works on both XAMPP and InfinityFree.
?>